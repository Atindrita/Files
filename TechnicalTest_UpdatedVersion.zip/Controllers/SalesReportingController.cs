﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2021.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication2021.Controllers
{
    [ApiController]
    [Route("/api/salesreporting")]
    public class SalesReportingController : ControllerBase
    {
        [HttpGet]
        [Route("totalsales")]
        public decimal GetTotalSales()
        {

            using (var db = new WebAppDbContext())
            {
                return db.Sales.Sum(s => s.UnitsSold * s.ProductSold.ProductSalePrice);
            }
        }

        [HttpGet]
        [Route("totalsalesbyproduct")]
        public decimal GetTotalSalesByProduct(int productId)
        {

            using (var db = new WebAppDbContext())
            {
                return db.Sales.Where(s => s.ProductSold.Id == productId).Sum(s => s.UnitsSold * s.ProductSold.ProductSalePrice);
            }
        }



        [HttpGet]
        [Route("totalsalesbyclient")]
        public decimal GetTotalSalesByClient(int clientId)
        {

            using (var db = new WebAppDbContext())
            {
                return db.Sales.Where(s => s.ClientSoldTo.Id == clientId).Sum(s => s.UnitsSold * s.ProductSold.ProductSalePrice);
            }
        }

        [HttpGet]
        [Route("clientsalesprofit")]
        public List<ClientSalesProfitDTO> GetClientSalesProfit()
        {

            using (var db = new WebAppDbContext())
            {
                return db.Clients.Include(c => c.Sales).ThenInclude(s => s.ProductSold).Select(c => new ClientSalesProfitDTO()
                {
                    ClientId = c.Id,
                    ClientName = c.ClientName,
                    TotalSalesIncome = c.Sales.Sum(s => s.UnitsSold * s.ProductSold.ProductSalePrice),
                }).ToList();
                    
            }
        }

        //Added
        [HttpGet]
        [Route("allproducts")]
        public List<Product> GetAllProducts()
        {

            using (var db = new WebAppDbContext())
            {
                return db.Products.ToList();
            }
        }

        [HttpGet]
        [Route("clientexpenses")]
        public List<ClientSalesProfitDTO> GetClientExpenses()
        {

            using (var db = new WebAppDbContext())
            {
                return db.Clients.Include(c => c.Sales).ThenInclude(s => s.ProductSold).Select(c => new ClientSalesProfitDTO()
                {
                    ClientId = c.Id,
                    ClientName = c.ClientName,
                    TotalSalesIncome = c.Sales.Sum(s => s.UnitsSold * s.ProductSold.ProductCost),
                }).ToList();

            }
        }
        
        [HttpGet]
        [Route("productexpensesandsales")]
        public List<Product> GetProductExpensesAndSales()
        {

            using (var db = new WebAppDbContext())
            {
                return db.Products.Include(p => p.SalesOfProduct).ThenInclude(s => s.ProductSold).Select(p => new Product()
                {
                    Id = p.Id,
                    ProductName = p.ProductName,
                    ProductSalePrice = p.SalesOfProduct.Sum(s => s.UnitsSold * s.ProductSold.ProductSalePrice),
                    ProductCost = p.SalesOfProduct.Sum(s => s.UnitsSold * s.ProductSold.ProductCost)
                }).ToList();

            }
        }

        [HttpGet]
        [Route("totalexpensesbyproduct")]
        public decimal GetTotalExpensesByProduct(int productId)
        {

            using (var db = new WebAppDbContext())
            {
                return db.Sales.Where(s => s.ProductSold.Id == productId).Sum(s => s.UnitsSold * s.ProductSold.ProductCost);
            }
        }

        [HttpGet]
        [Route("totalunitssoldbyclient")]
        public List<ClientSalesProfitDTO> GetTotalUnitsSoldByClient(int clientId)
        {

            using (var db = new WebAppDbContext())
            {
                return db.Clients.Include(c => c.Sales).ThenInclude(s => s.ClientSoldTo).Select(c => new ClientSalesProfitDTO()
                {
                    ClientId = c.Id,
                    ClientName = c.ClientName,
                    TotalSalesIncome = c.Sales.Sum(s => s.UnitsSold),
                }).ToList();
            }
        }
    }
}
